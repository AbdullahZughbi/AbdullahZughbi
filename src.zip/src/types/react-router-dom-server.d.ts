declare module "react-router-dom/server" {
  export * from "react-router-dom";
}
