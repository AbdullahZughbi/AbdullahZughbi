import "express-session";

declare module "express-session" {
  interface SessionData {
    backURL?: string | null;
  }
}
