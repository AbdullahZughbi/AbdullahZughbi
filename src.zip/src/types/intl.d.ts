// src/types/intl.d.ts

declare module "intl" {
  export class NumberFormat {
    constructor(language: string);
    format(number: number): string;
  }
  
  export function __disableRegExpRestore(): void;
}
