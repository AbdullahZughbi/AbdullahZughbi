interface PasswordOptions {
  string?: string;
  length?: number;
}

interface CaptchaOptions {
  string?: string;
  length?: number;
}

interface NumberGeneratorOptions {
  min: number;
  max: number;
}

declare class RandoStrings {
  /**
   * Generate a random password string.
   * @param option Optional options object with string charset and length.
   * @returns Generated random password string.
   */
  password(option?: PasswordOptions): string;

  /**
   * Generate a random captcha string.
   * @param option Optional options object with string charset and length.
   * @returns Generated random captcha string.
   */
  captcha(option?: CaptchaOptions): string;

  /**
   * Generate a random number between min and max (inclusive).
   * @param option Options object with min and max numbers.
   * @throws If min/max are missing, invalid, or min > max.
   * @returns Generated random number.
   */
  numberGenerator(option: NumberGeneratorOptions): number;
}

export = RandoStrings;
