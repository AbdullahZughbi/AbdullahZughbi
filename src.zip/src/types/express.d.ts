import "express";

declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      avatar?: string | null | undefined;
      guilds?: any[];
    }
  }
}
