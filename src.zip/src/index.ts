import dotenv from "dotenv";
dotenv.config();

import BotClient from "./Bot";
import config from "./config.json";
import emoji from "./src/data/emoji";
import logger from "./src/utils/logger";

const Bot = new BotClient(config);
Bot.emoji = emoji;

Bot.start(process.env.TOKEN);

process.on("unhandledRejection", (reason: unknown, p) => {
  const message = reason instanceof Error ? reason.message : String(reason);
  logger.info(`[unhandledRejection] ${message}`, { label: "ERROR" });
  console.error(reason, p);
});

process.on("uncaughtException", (err, origin) => {
  logger.info(`[uncaughtException] ${err.message}`, { label: "ERROR" });
  console.error(err, origin);
});

process.on("uncaughtExceptionMonitor", (err, origin) => {
  logger.info(`[uncaughtExceptionMonitor] ${err.message}`, { label: "ERROR" });
  console.error(err, origin);
});

/* process.on("multipleResolves", (type, promise, reason) => {
  logger.info(`[multipleResolves] MULTIPLE RESOLVES`, { label: "ERROR" });
  console.log(type, promise, reason);
}); */
