import Event from "../../structures/Event";
import config from "../../../config.json";
import logger from "../../utils/logger";
import Discord from "discord.js";

const webhookClient = new Discord.WebhookClient({
    url: config.webhooks.errors,
});

export default class extends Event {
    public async run(error: any, message: Discord.Message): Promise<void> {
      (message.channel as Discord.TextChannel).send(`An API Error has occured, make sure to report it here ${config.discord}`).catch(() => {});

      let content = message.content;
      if (content.length > 1024) content = content.slice(0, 1021) + "...";
      
      console.error(error);
      
      const embed = new Discord.EmbedBuilder()
        .setTitle("API Error")
        .setThumbnail((message.member as Discord.GuildMember).displayAvatarURL() as string)
        .addFields([
          {
            name: "Guild",
            value: `**${message.guild?.name}** (${message.guild?.id})`,
            inline: true,
          },
          {
            name: "User",
            value: `<@${message.member?.id}> **${message.member?.user.username}** (${message.member?.id})`,
            inline: true,
          },
          {
            name: "Content",
            value: `${content}`,
            inline: true,
          },
          {
            name: "Error",
            value: `${error.message}`,
            inline: true,
          }
        ])
        .setColor("#050000");
      
      webhookClient.send({
        embeds: [embed],
      });
    }
};
