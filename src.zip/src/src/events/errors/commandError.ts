import Event from "../../structures/Event";
import Discord from "discord.js";
import config from "../../../config.json";
import logger from "../../utils/logger";

const webhookClient = new Discord.WebhookClient({
    url: config.webhooks.errors,
});

export default class extends Event {
    public async run(error: any, message: Discord.Message, cmd: string, args: string[]): Promise<void> {
      if (error.code === "ECONNREFUSED") {
        (message.channel as Discord.TextChannel).send({
          content: "⚠️ Unable to connect to the database. Please check if the database is running and accessible.",
          components: [
            new Discord.ActionRowBuilder<Discord.ButtonBuilder>().addComponents(
              new Discord.ButtonBuilder()
                .setLabel("Report it here")
                .setURL(`${config.discord}`)
                .setCustomId("Link"),
            ),
          ],
        }).catch(() => {});
        return;
      }
      
      (message.channel as Discord.TextChannel).send(`${this.client.emoji.fail} Hey user! An error just occured, make sure to report it here ${config.discord}`).catch(() => {});
      
      let content = message.content;
      if (content.length > 1024) content = content.slice(0, 1021) + "...";
      
      console.error(error);
      
      const embed = new Discord.EmbedBuilder()
        .setTitle("Command Error")
        .setThumbnail((message.member as Discord.GuildMember).displayAvatarURL())
        .addFields([
          {
            name: "Guild",
            value: `**${message.guild?.name}** (${message.guild?.id})`,
            inline: true,
          },
          {
            name: "User",
            value: `<@${message.member?.id}> **${message.member?.user.username}** (${message.member?.id})`,
            inline: true,
          },
          {
            name: "Command Name",
            value: `${cmd}`,
            inline: true,
          },
          {
            name: "Content",
            value: `${content}`,
            inline: true,
          },
          {
            name: "Error",
            value: `${error.message}`,
            inline: true,
          }
        ])
        .setColor("#050000");
      
      webhookClient.send({
        embeds: [embed],
      });
    }
};
