import Event from "../../structures/Event";
import config from "../../../config.json";
import logger from "../../utils/logger";
import Discord from "discord.js";

const webhookClient = new Discord.WebhookClient({
    url: config.webhooks.errors,
});

export default class extends Event {
    public async run(error: any, interaction: Discord.ButtonInteraction): Promise<void> {
      await interaction.followUp({
        content: `${this.client.emoji.fail} Hey user! An error just occured, make sure to report it here ${config.discord}`,
        ephemeral: false,
      }).catch(() => console.error);
      
      console.error(error);
      
      const embed = new Discord.EmbedBuilder()
        .setTitle("Button Error")
        .setThumbnail((interaction.member as Discord.GuildMember).displayAvatarURL())
        .setColor("#050000");
      
      if (interaction.guild) {
        embed.addFields({
          name: "Guild",
          value: `**${interaction.guild.name}** (${interaction.guild.id})**`,
          inline: true,
        });
      }
      
      embed
        .addFields([
          {
            name: "User",
            value: `<@${interaction.user.id}> **${interaction.user.username}** (${interaction.user.id})`,
            inline: true,
          },
          {
            name: "Custom ID",
            value: `${interaction.customId}`,
            inline: true,
          },
          {
            name: "Error",
            value: `${error.message}`,
            inline: true,
          }
        ]);
      
      webhookClient.send({
        embeds: [embed],
      });
    }
};
