import Event from "../structures/Event";
import logger from "../utils/logger";
import {
  Client
} from "discord.js";
import dashboard from "../dashboard/dashboard";
import config from "../../config.json";

export default class extends Event {
  public async run(): Promise<void> {
    logger.info(
      `${this.client.user?.tag} is ready to servers ${this.client.guilds?.cache.size} guilds.`,
      { label: "Ready" }
    );
    
    if (config.dashboard) {
      await dashboard(this.client);
    }
  }
};
