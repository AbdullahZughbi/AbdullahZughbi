import Event from "../../structures/Event";
import {
  Permissions,
  PermissionsBitField,
  Collection,
  GuildMember,
  Message,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  TextChannel,
  Guild as _Guild,
  ButtonStyle,
  GuildChannel
} from "discord.js";
import logger from "../../utils/logger";
import GuildDB from "../../database/schemas/Guild";
import BlacklistDB from "../../database/schemas/blacklist";
import permissions from "../../assets/json/permissions";
import MaintenanceDB from "../../database/schemas/maintenance";
import config from "../../../config.json";
import moment from "moment";

const maintenanceCooldown = new Set();

interface UserRateLimits {
  [commandName: string]: number;
}

export default class extends Event {
  private ratelimits: Collection<string, UserRateLimits>;

  constructor(...args: [any, any]) {
    super(...args);

    this.ratelimits = new Collection();
  }

  public async run(message: Message): Promise<any> {
    try {
      if (!message.guild || message.author.bot) return;

      const mentionRegex = RegExp(`^<@!?${this.client.user?.id}>$`);
      const mentionRegexPrefix = RegExp(`^<@!?${this.client.user?.id}>`);
      
      const _GuildDB = GuildDB(this.client.sequelize);
      
      let settings = await _GuildDB.findOne({
        where: {
          guildId: (message.guild as _Guild).id,
        },
      });

      if (!settings) {
        settings = await _GuildDB.create({
          guildId: (message.guild as _Guild).id,
          prefix: config.prefix,
        });
      }

      const Maintenance = MaintenanceDB(this.client.sequelize);
      const Blacklist = BlacklistDB(this.client.sequelize);
      
      if (message.content.match(mentionRegex)) {
        const prefix = settings.prefix;

        const button = new ButtonBuilder()
          .setLabel("Invite")
          .setStyle(ButtonStyle.Link)
          .setURL(config.invite_link);
        const button3 = new ButtonBuilder()
          .setLabel("Support")
          .setStyle(ButtonStyle.Link)
          .setURL("https://discord.gg/Wrqm2VHVXH");
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button, button3);
        const embed = new EmbedBuilder()
          .setDescription(`Hi! I'm **GOD**\nTo get started type **${prefix}help**`)
          .setFooter({
            text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
            iconURL: (message.member as GuildMember).displayAvatarURL(),
          })
          .setColor("#050000");

        (message.channel as TextChannel).send({ embeds: [embed], components: [row] });
      }

      let mainPrefix = settings ? settings.prefix : "G!";
      const prefix = message.content.startsWith(settings?.prefix)
        ? settings.prefix
        : message.content.match(mentionRegexPrefix)?.[0] || mainPrefix;
      
      const userBlacklistSettings = await Blacklist.findOne({
        where: {
          discordId: (message.member as GuildMember).id,
        },
      });

      const guildBlacklistSettings = await Blacklist.findOne({
        where: {
          guildId: (message.guild as _Guild).id,
        },
      });

      if (!message.content.startsWith(prefix)) return;
      const [cmd, ...args] = message.content.slice(prefix.length).trim().split(/ +/g);
      const command = this.client.commands.get(cmd.toLowerCase());

      if (command) {
        let disabledCommands = settings.disabledCommands;
        if (typeof disabledCommands === "string") {
          disabledCommands = JSON.parse(disabledCommands);
          if (typeof disabledCommands === "string") {
            disabledCommands = JSON.parse(disabledCommands);
          }
        }

        if ((disabledCommands as unknown as string[]).includes(command.name || command)) return;

        const rateLimit = this.ratelimit(message, cmd);

        if (userBlacklistSettings && userBlacklistSettings.isBlacklist) {
          logger.warn(
            `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id}) tried to use "${cmd}" command but the user is blacklisted. Guild: **${(message.guild as _Guild).name}** (${(message.guild as _Guild).id})`,
            { label: "Commands" }
          );
          (message.channel as TextChannel).send(
            `You are blacklisted${userBlacklistSettings.length ? ` for <t:${Math.floor((userBlacklistSettings.length as unknown as Date).getTime() / 1000)}:F>!` : "!"}\n\n${userBlacklistSettings.reason ? `\`\`\`Reason: ${userBlacklistSettings.reason}\`\`\`` : "**No reason provided**"}`
          ).catch(() => {});

          let guildOwner = await (message.guild as _Guild).fetchOwner().then((m: any) => m.user).catch(() => {});

          if ((message.member as GuildMember).id === guildOwner.id) {
            if (!guildBlacklistSettings) {
              await Blacklist.create({
                guildId: (message.guild as _Guild).id,
                type: "guild",
                isBlacklist: true,
                length: userBlacklistSettings.length ? (userBlacklistSettings.length as unknown as Date).getTime() : null,
                reason: userBlacklistSettings.reason || null,
              });
            }
            await (message.guild as _Guild).leave().catch(() => {});
          }
          return;
        }
        
        
        if (guildBlacklistSettings && guildBlacklistSettings.isBlacklist) {
          logger.warn(
            `<@${(message.member as GuildMember).id}> **${(message.member as GuildMember).user.username}** (${(message.member as GuildMember).id}) tried to use "${cmd}" command but the guild: ${(message.guild as _Guild).name} ${(message.guild as _Guild).id} is blacklisted`,
            { label: "Commands" }
          );
          (message.channel as TextChannel).send(
            `This server is blacklisted${guildBlacklistSettings.length ? ` for <t:${Math.floor((guildBlacklistSettings.length as unknown as Date).getTime() / 1000)}:F>!` : "!"}\n\n${guildBlacklistSettings.reason ? `\`\`\`Reason: ${guildBlacklistSettings.reason}\`\`\`` : "**No reason provided**"}`
          ).catch(() => {});
          await (message.guild as _Guild).leave().catch(() => {});
          return;
        }

        let number = Math.floor(Math.random() * 10 + 1);
        if (typeof rateLimit === "number") {
          return (message.channel as TextChannel)
            .send(
              `${message.member} ${
                this.client.emoji.fail
              } Please wait <t:${rateLimit}:R> before running the **${cmd}** command again!`
            )
            .then((s: any) => {
              message.delete().catch(() => {});
              setTimeout(() => {
                s.delete().catch(() => {});
              }, 4000);
            })
            .catch(() => {});
        }

        if (command.botPermission) {
          let missingPermissions: string[] = [];
          const botMember = (message.guild as _Guild)?.members.me as GuildMember | null;
          const channel = message.channel as TextChannel | null;
          
          if (channel && botMember) {
            missingPermissions = channel
              .permissionsFor(botMember.id)
              ?.missing(command.botPermission)
              .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
          }
          if (missingPermissions.length !== 0) {
            const embedd = new EmbedBuilder()
              .setDescription(`❌ I don't have **${missingPermissions.join(", ")}** permission.\n\n**Need help?**\nhttps://${process.env.DOMAIN}/help/other-permissions`)
              .setColor("#992d22");
            return (message.channel as TextChannel).send({
              embeds: [embedd],
            }).catch(() => {});
          }
        }

        if (command.userPermission) {
          let missingPermissions: string[] = [];
          const channel = message.channel as TextChannel | GuildChannel | null;
          const member = message.member as GuildMember | null;
          if (channel && member) {
            missingPermissions = channel
              .permissionsFor(member.id)
              ?.missing(command.userPermission)
              .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
          }
          
          if (missingPermissions.length !== 0) {
            const embed = new EmbedBuilder()
              .setAuthor({
                name: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL(),
              })
              .setDescription(`You don't have **${missingPermissions.join(", ")}** permissions`)
              .setColor(`#000000`);
            return (message.channel as TextChannel).send({
              embeds: [embed],
            }).catch(() => {});
          }
        }

        if (command.ownerOnly) {
          if (!this.client.config.developers.includes((message.member as GuildMember).id)) return;
        }

        if (command.disabled) {
          const disabledButton = new ButtonBuilder()
            .setCustomId("Support")
            .setStyle(ButtonStyle.Link)
            .setURL("https://discord.gg/Wrqm2VHVXH");
          const disabledRow = new ActionRowBuilder<ButtonBuilder>().addComponents(disabledButton);
          return (message.channel as TextChannel).send({
            content: `Developer(s) have disabled the command for now. Try again Later!\n\nFor updates, click the button below:`,
            components: [disabledRow],
          });
        }

        await this.runCommand(message, cmd, args);
      }
    } catch (error) {
      return this.client.emit("fatalError", error, message);
    }
  }

  private async runCommand(message: Message, cmd: string, args: string[]): Promise<void> {
    const command = this.client.commands.get(cmd.toLowerCase());

    if (command) {
      try {
        await command.execute(message, args);
      } catch (error) {
        this.client.emit("commandError", error, message, cmd, args);
      }
    }
  }
  
  private ratelimit(message: Message, cmd: string): boolean | number | null {
    try {
      const command = this.client.commands.get(cmd.toLowerCase());
      if (!command) return false;

      const cooldown = command.cooldown * 1000;
      const userRateLimits = this.ratelimits.get((message.member as GuildMember).id) || {};
        
      if (!userRateLimits[command.name]) {
        userRateLimits[command.name] = Date.now() - cooldown;
      }

      const lastUsed = userRateLimits[command.name];
      const difference = Date.now() - lastUsed;

      if (difference < cooldown) {
          const cooldownEnd = Math.floor((lastUsed + cooldown) / 1000);
          return cooldownEnd;
      } else {
         userRateLimits[command.name] = Date.now();
          this.ratelimits.set((message.member as GuildMember).id, userRateLimits);
          return true;
        }
      } catch (e) {
        this.client.emit("fatalError", e, message);
        return false;
    }
  }
};
