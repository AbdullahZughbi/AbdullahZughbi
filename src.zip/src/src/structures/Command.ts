import {
  Message
} from "discord.js";
import ExtendedClient from "./ExtendedClient";

interface CommandOptions {
  name?: string;
  aliases?: string[];
  description?: string;
  category?: string;
  usage?: string;
  examples?: string[];
  disabled?: boolean;
  cooldown?: number;
  ownerOnly?: boolean;
  guildOnly?: boolean;
  botPermission?: string[];
  userPermission?: string[] | null;
}

export default class Command {
  public client: ExtendedClient;
  public name: string;
  public aliases: string[];
  public description: string;
  public category: string;
  public usage: string;
  public examples: string[];
  public disabled: boolean;
  public cooldown: number;
  public ownerOnly: boolean;
  public guildOnly: boolean;
  public botPermission: string[];
  public userPermission: string[] | null;

  constructor(client: ExtendedClient, name: string, options: CommandOptions = {}) {
    this.client = client;
    this.name = options.name || name;
    this.aliases = options.aliases || [];
    this.description = options.description || "No description provided.";
    this.category = options.category || "General";
    this.usage = `${this.name} ${options.usage || ""}`.trim();
    this.examples = options.examples || [];
    this.disabled = options.disabled || false;
    this.cooldown = "cooldown" in options ? options.cooldown! : 5;
    this.ownerOnly = options.ownerOnly || false;
    this.guildOnly = options.guildOnly || false;
    this.botPermission = options.botPermission || [];
    this.userPermission = options.userPermission ?? null;
  }

  public async run(message: Message, args: string[]): Promise<void> {
    throw new Error(`The run method has not been implemented in ${this.name}`);
  }
};
