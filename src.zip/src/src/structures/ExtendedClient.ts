import {
  Client,
  Collection,
} from "discord.js";
import {
  Sequelize,
} from "sequelize";
import Util from "./Util";
import config from "../../config.json";

export default class ExtendedClient extends Client {
  public sequelize!: Sequelize;
  public commands!: Collection<string, any>;
  public aliases!: Collection<string, string>;
  public slashcommands!: Collection<string, any>;
  public buttons!: Collection<string, any>;
  public selectmenus!: Collection<string, any>;
  public modals!: Collection<string, any>;
  public events!: Collection<string, any>;
  public emoji!: any;
  public utils!: Util;
  public config!: typeof config;
  public prefix!: string;

  constructor(options: any) {
    super(options);
  }
};
