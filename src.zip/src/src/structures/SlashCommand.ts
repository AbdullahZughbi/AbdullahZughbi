import {
  ChatInputCommandInteraction,
  ApplicationCommandOptionData,
} from "discord.js";
import ExtendedClient from "./ExtendedClient";

interface SlashCommandOptions {
  name?: string;
  description?: string;
  options?: ApplicationCommandOptionData[];
  dm_permission?: boolean;
  // integration_types?: string[];
  // contexts?: string[];
}

export default class SlashCommand {
  public client: ExtendedClient;
  public name: string;
  public description: string;
  public options: ApplicationCommandOptionData[];
  public dm_permission?: boolean;
  // public integration_types?: string[];
  // public contexts?: string[];

  constructor(client: ExtendedClient, name: string, options: SlashCommandOptions = {}) {
    this.client = client;
    this.name = options.name || name;
    this.description = options.description || "No description provided.";
    this.options = options.options || [];
    this.dm_permission = options.dm_permission;
    // this.integration_types = options.integration_types;
    // this.contexts = options.contexts;
  }

  public async run(interaction: ChatInputCommandInteraction, args: string[]): Promise<void> {
    throw new Error(`The run method has not been implemented in ${this.name}`);
  }
};
