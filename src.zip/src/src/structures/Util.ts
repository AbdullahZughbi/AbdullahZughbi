import fs from "fs/promises";
import path from "path";
import {
  pathToFileURL,
  fileURLToPath,
} from "url";
import {
  Client,
  Collection,
} from "discord.js";
import Command from "./Command";
import Modal from "./Modal";
import Event from "./Event";
import Button from "./Button";
import SelectMenu from "./SelectMenu";
import SlashCommand from "./SlashCommand";
import ContextMenuCommand from "./ContextMenuCommand";
import logger from "../utils/logger";
import {
  Sequelize
} from "sequelize";
import ExtendedClient from "./ExtendedClient";

export default class Util {
  public client: ExtendedClient;

  constructor(client: ExtendedClient) {
    this.client = client;
  }

  private isClass(input: any): boolean {
    return (
      typeof input === "function" &&
      typeof input.prototype === "object" &&
      input.toString().startsWith("class")
    );
  }

  private trimArray(arr: string[], maxLen = 10): string[] {
    if (arr.length > maxLen) {
      const len = arr.length - maxLen;
      arr = arr.slice(0, maxLen);
      arr.push(`${len} more...`);
    }
    return arr;
  }

  private get directory(): string {
    const mainFilename = require.main ? require.main.filename : process.cwd();
    return `${path.dirname(mainFilename)}${path.sep}`;
  }

  private removeDuplicates<T>(arr: T[]): T[] {
    return [...new Set(arr)];
  }

  private capitalise(str: string): string {
    return str
      .split(" ")
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(" ");
  }

  public async *loadFiles(dir: string): AsyncGenerator<string> {
    try {
      await fs.access(dir);
    } catch {
      await fs.mkdir(dir, { recursive: true });
    }

    const files = await fs.readdir(dir);
    for (const file of files) {
      const filePath = path.join(dir, file);
      const stat = await fs.stat(filePath);
      if (stat.isDirectory()) {
        yield* this.loadFiles(filePath);
      } else {
        if (!file.endsWith(".js")) continue; // Skip non-JS files
        yield filePath;
      }
    }
  }

  public async loadDatabases(): Promise<void> {
    try {
      await this.client.sequelize.authenticate();
      logger.info("Connection", { label: "DATABASE" });
    } catch (err) {
      throw err;
    }
    
    const schemas: string[] = [
      "blacklist",
      "Guild",
      "maintenance"
    ];
    const models: string[] = [];

    for (const schema of schemas) {
      const { default: applySchema } = await import(`../database/schemas/${schema}`);
      applySchema(this.client.sequelize);
    }

    for (const model of models) {
      const { default: applyModel } = await import(`../database/models/${model}`);
      applyModel(this.client.sequelize);
    }
    
    await this.client.sequelize.sync({ force: false });
    logger.info("Resync", { label: "DATABASE" });
  }

  private async loadClassFromFile<T>(
    file: string,
    BaseClass: new (...args: any[]) => T,
    name: string,
    instanceArgs: any[] = []
  ): Promise<T> {
    const imported = await require(file);
    const Class = imported.default ?? imported;
    if (!this.isClass(Class)) throw new TypeError(`${name} doesn't export a class.`);
    const instance = new Class(...instanceArgs);
    if (!(instance instanceof BaseClass)) throw new TypeError(`${name} doesn't belong in ${BaseClass.name}s.`);
    return instance;
  }

  public async loadCommands(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/commands`)) {
      const { name } = path.parse(file);
      const command = await this.loadClassFromFile(file, Command, `Command ${name}`, [this.client, name.toLowerCase()]);
      this.client.commands.set(command.name, command);
      for (const alias of command.aliases || []) {
        this.client.aliases.set(alias, command.name);
      }
    }
  }

  public async loadSlashCommands(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/slashCommands`)) {
      const { name } = path.parse(file);
      const slash = await this.loadClassFromFile(file, SlashCommand, `Slash command ${name}`, [this.client, name.toLowerCase()]);
      this.client.slashcommands.set(slash.name, slash);
    }
  }

  public async loadButtons(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/components/buttons`)) {
      const { name } = path.parse(file);
      const button = await this.loadClassFromFile(file, Button, `Button ${name}`, [this.client, name]);
      this.client.buttons.set(button.name, button);
    }
  }

  public async loadContextMenuCommands(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/contextMenuCommands`)) {
      const { name } = path.parse(file);
      const cmd = await this.loadClassFromFile(file, ContextMenuCommand, `Context Menu Command ${name}`, [this.client, name]);
      this.client.slashcommands.set(cmd.name, cmd);
    }
  }

  public async loadSelectMenus(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/components/selectMenus`)) {
      const { name } = path.parse(file);
      const select = await this.loadClassFromFile(file, SelectMenu, `Select Menu ${name}`, [this.client, name]);
      this.client.selectmenus.set(select.name, select);
    }
  }

  public async loadModals(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/components/modals`)) {
      const { name } = path.parse(file);
      const modal = await this.loadClassFromFile(file, Modal, `Modal ${name}`, [this.client, name]);
      this.client.modals.set(modal.name, modal);
    }
  }

  public async loadEvents(): Promise<void> {
    for await (const file of this.loadFiles(`${this.directory}/src/events`)) {
      const { name } = path.parse(file);
      const event = await this.loadClassFromFile(file, Event, `Event ${name}`, [this.client, name]);
      this.client.events.set(event.name, event);
      event.emitter[event.type](name, (...args: any[]) => event.run(...args));
    }
  }
};
