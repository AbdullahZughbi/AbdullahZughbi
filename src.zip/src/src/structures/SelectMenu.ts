import {
  Interaction
} from "discord.js";
import ExtendedClient from "./ExtendedClient";

interface SelectMenuOptions {
  name?: string;
}

export default class SelectMenu {
  public client: ExtendedClient;
  public name: string;
  
  constructor(client: ExtendedClient, name: string, options: SelectMenuOptions) {
    this.client = client;
    this.name = options.name || name;
  }
  
  public async run(interaction: Interaction): Promise<void> {
    throw new Error(`The run method has not been implemented in ${this.name}`);
  }
};
