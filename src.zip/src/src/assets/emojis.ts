export default {
  "success": "<a:check:1145111982626844733> ",
  "fail": "❌ "
};
