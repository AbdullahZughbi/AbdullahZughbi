export default {
  "ViewChannel": "VIEW CHANNEL",
  "ManageChannels": "MANAGE CHANNELS",
  "ManageRoles": "MANAGE ROLES",
  "CreateGuildExpressions": "CREATE EXPRESSIONS",
  "ManageGuildExpressions": "MANAGE EXPRESSIONS",
  "ManageEmojisAndStickers": "MANAGE EXPRESSIONS",
  "ViewAuditLog": "VIEW AUDIT LOG",
  "ViewGuildInsights": "VIEW GUILD INSIGHTS",
  "ManageWebhooks": "MANAGE WEBHOOKS",
  "ManageGuild": "MANAGE GUILD",
  
  
  "CreateInstantInvite": "CREATE INVITE",
  "ChangeNickname": "CHANGE NICKNAME",
  "ManageNicknames": "MANAGE NICKNAMES",
  "KickMembers": "KICK MEMBERS",
  "BanMembers": "BAN MEMBERS",
  "ModerateMembers": "TIME OUT MEMBERS",
  
  
  "SendMessages": "SEND MESSAGES",
  "SendMessagesInThreads": "SEND MESSAGES IN THREADS",
  "CreatePublicThreads": "CREATE PUBLIC THREADS",
  "CreatePrivateThreads": "CREATE PRIVATE THREADS",
  "EmbedLinks": "EMBED LINKS",
  "AttachFiles": "ATTACH FILES",
  "AddReactions": "ADD REACTIONS",
  "UseExternalEmojis": "USE EXTERNAL EMOJIS",
  "UseExternalStickers": "USE EXTERNAL STICKERS",
  "MentionEveryone": "MENTION @everyone, @here AND ALL ROLES",
  "ManageMessages": "MANAGE MESSAGES",
  "ManageThreads": "MANAGE THREADS",
  "ReadMessageHistory": "READ MESSAGE HISTORY",
  "SendTTSMessages": "SEND TEXT-TO-SPEECH MESSAGES",
  "SendVoiceMessages": "SEND VOICE MESSAGES",
  "SendPolls": "CREATE POLLS",
  
  
  "Connect": "CONNECT",
  "Speak": "SPEAK",
  "Stream": "VIDEO",
  "UseSoundboard": "USE SOUNDBOARD",
  "UseExternalSounds": "USE EXTERNAL SOUNDS",
  "UseVAD": "USE VOICE ACTIVITY",
  "PrioritySpeaker": "PRIORITY SPEAKER",
  "MuteMembers": "MUTE MEMBERS",
  "DeafenMembers": "DEAFEN MEMBERS",
  "MoveMembers": "MOVE MEMBERS",
  
  
  "UseApplicationCommands": "USE APPLICATION COMMANDS",
  "UseEmbeddedActivities": "USE ACTIVITIES",
  
  
  "RequestToSpeak": "REQUEST TO SPEAK",
  
  
  "CreateEvents": "CREATE EVENTS",
  "ManageEvents": "MANAGE EVENTS",
  
  
  "Administrator": "ADMINISTRATOR"
};
