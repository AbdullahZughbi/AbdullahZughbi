import Command from "../../structures/Command";
import {
  Status,
  TextChannel,
  Message
} from "discord.js";

export default class extends Command {
  constructor(...args: [any, any]) {
    super(...args, {
      name: "ping",
      description: "Ping pong",
      category: "Information",
      cooldown: 5,
    });
  }

  public async run(message: Message, args: string[]): Promise<void> {
    const latency = Date.now() - message.createdTimestamp;
    
    let dbLatency;
    try {
      const start = Date.now();
      await this.client.sequelize.query('SELECT 1');
      dbLatency = Date.now() - start;
    } catch (error) {
      dbLatency = 'N/A';
    }

    let formattedSize = 'N/A';
    try {
      const [results] = await this.client.sequelize.query(`
        SELECT 
          SUM(data_length + index_length) / 1024 / 1024 AS "Size (MB)"
        FROM information_schema.tables
        WHERE table_schema = DATABASE();
      `) as unknown as any[];
      
      if (results.length > 0 && results[0]['Size (MB)'] !== null) {
        formattedSize = formatSize(parseFloat(results[0]['Size (MB)']));
      }
    } catch (error) {
      formattedSize = 'N/A';
    }

    let connectionStatus;
    switch (this.client.ws.status) {
      case Status.Ready:
        connectionStatus = "Ready";
        break;
      case Status.Connecting:
        connectionStatus = "Connecting";
        break;
      case Status.Reconnecting:
        connectionStatus = "Reconnecting";
        break;
      case Status.Idle:
        connectionStatus = "Idle";
        break;
      case Status.Nearly:
        connectionStatus = "Nearly Ready";
        break;
      case Status.Disconnected:
        connectionStatus = "Disconnected";
        break;
      case Status.WaitingForGuilds:
        connectionStatus = "Waiting For Guilds";
        break;
      case Status.Identifying:
        connectionStatus = "Identifying";
        break;
      case Status.Resuming:
        connectionStatus = "Resuming";
        break;
      default:
        connectionStatus = "Unknown";
        break;
    }
    
    const pingResponse: string = `**Status:** \`${connectionStatus}\`
**Latency:** \`${latency}ms\`
**Discord API:** \`${Math.round(this.client.ws.ping)}ms\`
**Database Latency:** \`${dbLatency}ms\`
**Database Size:** \`${formattedSize}\``;

    (message.channel as TextChannel).send(pingResponse).catch(() => {});
  }
};

function formatSize(sizeMB: number): string {
    const bytes = sizeMB * 1024 * 1024;
    if (bytes < 1024) return `${bytes.toFixed(0)} Bytes`;
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(2)} KB`;
    const mb = kb / 1024;
    if (mb < 1024) return `${mb.toFixed(2)} MB`;
    const gb = mb / 1024;
    if (gb < 1024) return `${gb.toFixed(2)} GB`;
    const tb = gb / 1024;
    return `${tb.toFixed(2)} TB`;
}
