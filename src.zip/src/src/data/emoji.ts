export default {
  x: "❌ ",
  fail: "❌ ",
  check: "<a:check:1145111982626844733>",
  success: "<a:check:1145111982626844733>",
  warning: "<:warning:1145113803151917146>",
  loading: "<a:loading:1270156278853009408>",
  stopwatch: "⏱️",
};
