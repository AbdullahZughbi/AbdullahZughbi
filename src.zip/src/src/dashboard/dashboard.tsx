import dotenv from "dotenv";
dotenv.config();

import discord, { EmbedBuilder } from "discord.js";
import url from "url";
import path from "path";
import express, { Response, Request, NextFunction } from "express";
import cookieParser from "cookie-parser";
import ejs from "ejs";
import ms from "ms";
import config from "../../config.json";
import randoStrings from "@loryreuploads/randostrings";
import ExtendedClient from "../structures/ExtendedClient";
import session from "express-session";
import passport from "passport";
import React from "react";
import { renderToString } from "react-dom/server";
import fs from "fs/promises";
const Strategy = require("./passport").Strategy;
import connectSequelize from "connect-session-sequelize";
import { StaticRouter } from "react-router";
import logger from "../utils/logger";

// Schemas
import BlacklistDB from "../database/schemas/blacklist";
import GuildDB from "../database/schemas/Guild";
import MaintenanceDB from "../database/schemas/maintenance";

// Type augmentation for session
type AuthRequest = Request & {
  session: session.Session & {
    backURL?: string | null;
  };
};

const SequelizeStore = connectSequelize(session.Store);
const random = new randoStrings();
const domain = process.env.AUTH_DOMAIN!;
const clientID = process.env.AUTH_CLIENT_ID!;
const secret = process.env.AUTH_CLIENT_SECRET!;
const port = Number(process.env.PORT) || 5000;

const app = express();
app.use(express.static("static"));

interface TemplateData {
  title?: string;
  description?: string;
  user?: any;
  [key: string]: any;
}

// Apps
import appIndex from "./apps/get/index";

interface DiscordUser {
  id: string;
  username: string;
  avatar?: string | null | undefined;
  guilds?: any[];
  [key: string]: any;
}

export default async (client: ExtendedClient) => {
  const dataDir = path.resolve(`${process.cwd()}${path.sep}src/dashboard`);
  const templateDir = path.resolve(`${dataDir}${path.sep}templates`);

  const store = new SequelizeStore({
    db: client.sequelize,
    expiration: 24 * 60 * 60 * 1000,
  });

  passport.serializeUser((user: DiscordUser, done) => {
    if (!user) return;
    return done(null, user as Express.User);
  });

  passport.deserializeUser((obj: DiscordUser, done) => {
    return done(null, obj as Express.User);
  });

  passport.use(
    new Strategy(
      {
        clientID,
        clientSecret: secret,
        callbackURL: `${domain}/callback`,
        scope: ["identify", "guilds"],
      },
      async (
        accessToken: string,
        refreshToken: string,
        profile: DiscordUser,
        cb: (err: any, user?: DiscordUser | false) => void
      ) => {
        await process.nextTick(() => {
          if (profile.guilds == undefined) return cb(null, false);
          return cb(null, profile);
        });
      }
    )
  );

  app.use(
    session({
      secret: process.env.SESSION_SECRET!,
      resave: false,
      saveUninitialized: false,
      store: store,
    })
  );

  app.use(passport.initialize());
  app.use(passport.session());

  app.locals.domain = domain.split("//")[1];
  app.engine("html", ejs.renderFile);
  app.set("view engine", "html");

  app.use(cookieParser());

  const renderTemplate = async (res: Response, req: Request, template: string, data: TemplateData = {}) => {
    try {
      const templatePath = path.resolve(__dirname, `templates/${template}`);
      const { default: Component } = await import(templatePath);

      const _data = {
        config,
        domain,
        bot: client,
        clientID: process.env.MAIN_CLIENT_ID,
        pathname: url.parse(req.url).pathname,
        path: req.path,
        user: req.isAuthenticated() ? req.user : null,
        image: `${domain}/logo.png`,
        seo: config.seo.enabled,
        description: config.seo.enabled ? config.seo.description : undefined,
        title: data.title ?? config.seo.title,
        ...data,
      };

      const jsx = (
        <StaticRouter location={req.url}>
          <Component {..._data} />
        </StaticRouter>
      );

      const html = renderToString(jsx);
      
      const ejsPath = path.resolve(
        __dirname,
        "templates",
        "index.ejs"
      );
      
      ejs.renderFile(
        ejsPath,
        {
          html: html,
          ..._data
        },
        (err, str) => {
          try {
            if (err) {
              console.error("EJS render error", err);
              res.status(500).send("Internal Server Error");
              return;
            } else {
              res.send(str);
              return;
            }
          } catch (err) {
            console.error(err);
            if (!res.writableEnded) {
              res.status(500).send("Internal Server Error");
            }
          }
        },
      );
    } catch (error) {
      console.error("Error rendering template:", error);
      if (!res.writableEnded) {
        res.status(500).send("Internal Server Error");
      }
    }
  };

  app.get("/login", (req: AuthRequest, res, next) => {
    req.session.backURL ||= "/dashboard";
    next();
  }, passport.authenticate("discord"));

  app.get("/callback", (req: AuthRequest, res, next) => {
    req.headers.referer = req.session.backURL as string;
    next();
  }, (req: AuthRequest, res, next) => {
    passport.authenticate("discord", { failureRedirect: "/" }, async (err: any, user: any) => {
      if (err) {
        console.error(err);
        return res.redirect("/");
      }
      await req.login(user, (e) => {
        if (e) return next(e);
        return next();
      });
    })(req, res, next);
  }, async (req: AuthRequest, res) => {
    try {
      const loginLogs = new discord.WebhookClient({ url: config.webhooks.auth });
      const login = new EmbedBuilder()
        .setColor("#050000")
        .setTitle("Login Logs")
        .addFields([
          {
            name: "User",
            value: `<@${(req.user as any).id}> ${(req.user as any).username} (${(req.user as any).id})`,
            inline: true,
          },
          {
            name: "Time",
            value: `<t:${Math.floor(Date.now() / 1000)}:R>`,
            inline: true,
          },
        ]);

      await loginLogs.send({
        username: "Login Logs",
        avatarURL: `${domain}/logo.png`,
        embeds: [login],
      });

      const guildID = req.query.guild_id as string;
      const redirectTo = guildID
        ? `/dashboard/${guildID}`
        : req.headers.referer || req.session.backURL || "/dashboard";

      req.session.backURL = null;
      res.redirect(redirectTo);
    } catch (err) {
      res.redirect("/");
    }
  });

  app.get("/logout", async (req: AuthRequest, res) => {
    if (req.user) {
      const logoutLogs = new discord.WebhookClient({ url: config.webhooks.auth });
      const logout = new EmbedBuilder()
        .setColor("#050000")
        .setTitle("Logout Logs")
        .addFields([
          {
            name: "User",
            value: `<@${(req.user as any).id}> ${(req.user as any).username} (${(req.user as any).id})`,
            inline: true,
          },
          {
            name: "Time",
            value: `<t:${Math.floor(Date.now() / 1000)}:R>`,
            inline: true,
          },
        ]);

      await logoutLogs.send({
        username: "Logout Logs",
        avatarURL: `${domain}/logo.png`,
        embeds: [logout],
      });
    }

    req.session.destroy(() => {
      res.redirect("/");
    });
  });

  app.get("/support", (req: Request, res: Response) => {
    res.redirect(config.discord)
  });
  app.get("/server", (req: Request, res: Response) => {
    res.redirect(config.discord)
  });

  app.get("/invite", (req: Request, res: Response) => {
    const guildID = req.query.guildID as string;
    const inviteURL = `https://discord.com/oauth2/authorize?client_id=${clientID}&permissions=8&redirect_uri=${encodeURIComponent(
      domain + "/callback"
    )}&response_type=code&scope=bot%20applications.commands%20identify%20guilds`;

    res.redirect(guildID ? `${inviteURL}&guild_id=${guildID}` : inviteURL);
  });

  app.get("/policy", (req: Request, res: Response) => {
    res.send("Coming soon")
  });
  app.get("/terms", (req: Request, res: Response) => {
    res.send("Coming soon")
  });
  app.get("/premium", (req: Request, res: Response) => {
    res.send("Coming soon")
  });

  app.get("/", async (req: Request, res: Response) => {
    await appIndex(req, res, renderTemplate);
  });
  
  app.use((
    err: any,
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    console.error("Global error handler", err);
    
    if (res.writableEnded) {
      return next(err);
    }
    
    res.status(500).send("Internal Server Error");
  });
  
  app.listen(port, () => {
    logger.info(`Listening on port ${port}`, {
      label: "Dashboard",
    });
  });
};
