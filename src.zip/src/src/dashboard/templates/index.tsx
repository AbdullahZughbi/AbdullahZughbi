import React from "react";
import ReactDOM from "react-dom/client";
import Nav from "./partials/nav";

interface IndexProps {
  user?: any;
}

export const Index: React.FC<IndexProps> = ({ user }) => (
  <div>
    <Nav user={user} />
  </div>
);

export let root: ReactDOM.Root | null = null;

if (typeof window !== "undefined") {
  root = ReactDOM.createRoot(document.getElementById("root")!);
  const user = (window as any).__USER__ || null;
  root.render(<Index user={user} />);
}
