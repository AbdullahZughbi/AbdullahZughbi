import React from "react";
// import styles from "./static/styles/index.css";

// console.log(styles);

const Index: React.FC = () => {
  return (
    <div>
      <div>
        <h1>Hello World</h1>
      </div>
    </div>
  );
};

export default Index;
