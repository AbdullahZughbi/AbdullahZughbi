import React, { useState, useRef, useEffect } from "react";

interface User {
  username?: string;
  avatar?: string | null;
  id?: string;
}

interface NavProps {
  user?: User | null;
}

const Nav: React.FC<NavProps> = ({ user }) => {
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const [mobileMenuActive, setMobileMenuActive] = useState(false);

  const dropdownRef = useRef<HTMLUListElement>(null);
  const avatarContainerRef = useRef<HTMLAnchorElement>(null);

  const toggleDropdown = (event: React.MouseEvent) => {
    event.stopPropagation();
    setDropdownVisible((prev) => !prev);
  };

  const closeDropdown = () => {
    setDropdownVisible(false);
  };

  // New: Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuActive((prev) => !prev);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        avatarContainerRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        !avatarContainerRef.current.contains(event.target as Node)
      ) {
        closeDropdown();
      }
    };
    document.addEventListener("click", handleClickOutside);

    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  let avatar = "";
  if (user) {
    avatar = user.avatar
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
      : "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404.png?v=1602412158188";
  }

  return (
    <nav>
      <div className="nav-container">
        <div className="header__nav_bar">
          {/* Hamburger menu toggle */}
          <div className="toggle_menu" onClick={toggleMobileMenu}>
            <div className="line line1"></div>
            <div className="line line2"></div>
            <div className="line line3"></div>
          </div>

          {/* Nav list with active class toggled */}
          <ul className={`nav-list ${mobileMenuActive ? "active" : ""}`}>
            {user ? (
              <a
                className="avatar-container"
                id="dropdownHead"
                onClick={toggleDropdown}
                ref={avatarContainerRef}
                style={{ cursor: "pointer" }}
              >
                <img className="user-avatar" src={avatar} alt="User avatar" />
                <span className="user-name">{user.username}</span>
              </a>
            ) : (
              <li className="nav-list-item">
                <a href="/login" className="nav-link">
                  Login
                </a>
              </li>
            )}
            <li className="nav-list-item">
              <a href="/" className="nav-link">
                Home
              </a>
            </li>
            <li className="nav-list-item">
              <a href="/support" className="nav-link">
                Support
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Blur overlay */}
      <div
        className={`blur ${dropdownVisible ? "visible" : ""}`}
        onClick={closeDropdown}
      ></div>

      {/* User dropdown */}
      <ul
        className={`dropdown ${dropdownVisible ? "dropdown-visible" : ""}`}
        id="dropdown"
        ref={dropdownRef}
      >
        <li className="cross-container">
          <span className="cross" id="closeDropdown" onClick={closeDropdown}>
            &times;
          </span>
        </li>
        <li className="dropdown-li">
          <a className="logout" href="/logout">
            <i className="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </nav>
  );
};

export default Nav;
