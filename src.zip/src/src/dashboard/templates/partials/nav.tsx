import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";

interface NavProps {
  user?: {
    username: string;
    id: string;
    avatar: string | null | undefined;
  };
  onLogout?: () => void;
}

const PartialsNav: React.FC<NavProps> = ({ user }) => {
  const [isDropdownVisible, setDropdownVisible] = useState(false);
  const [isNavActive, setNavActive] = useState(false);

  const dropdownRef = useRef<HTMLUListElement>(null);
  const blurRef = useRef<HTMLDivElement>(null);
  const avatarRef = useRef<HTMLDivElement>(null);

  const avatar = user?.avatar
    ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
    : "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404.png?v=1602412158188";

  const toggleMenu = () => {
    setNavActive(!isNavActive);
  };

  const toggleDropdown = () => {
    setDropdownVisible(!isDropdownVisible);
  };

  const closeDropdown = () => {
    setDropdownVisible(false);
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        avatarRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        !avatarRef.current.contains(event.target as Node)
      ) {
        closeDropdown();
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  return (
    <>
      <nav className="nav-container">
        <div className="toggle_menu" onClick={toggleMenu}>
          <div className="line line1"></div>
          <div className="line line2"></div>
          <div className="line line3"></div>
        </div>
        <ul className={`nav-list ${isNavActive ? "active" : ""}`}>
          {user ? (
            <div className="avatar-container" id="dropdownHead" ref={avatarRef} onClick={(e) => {
              e.stopPropagation();
              toggleDropdown();
            }}>
              <img className="user-avatar" src={avatar} alt="User Avatar" />
              <span className="user-name">{user.username}</span>
            </div>
          ) : (
            <li className="nav-list-item">
              <Link to="/login" className="nav-link">Login</Link>
            </li>
          )}
          <li className="nav-list-item">
            <Link to="/" className="nav-link">Home</Link>
          </li>
          <li className="nav-list-item">
            <Link to="/support" className="nav-link">Support</Link>
          </li>
        </ul>
      </nav>

      <div
        className={`blur ${isDropdownVisible ? "visible" : ""}`}
        id="body-blur"
        ref={blurRef}
        onClick={closeDropdown}
      />

      <ul
        className={`dropdown ${isDropdownVisible ? "dropdown-visible" : ""}`}
        id="dropdown"
        ref={dropdownRef}
      >
        <li className="cross-container">
          <span className="cross" id="closeDropdown" onClick={closeDropdown}>
            &times;
          </span>
        </li>

        <li className="dropdown-li">
          <Link className="logout" to="/logout">
            <i className="fas fa-sign-out-alt"></i> Logout
          </Link>
        </li>
      </ul>
    </>
  );
};

export default PartialsNav;
