import { Request, Response } from "express";
import React from "react";

export default async (
  req: Request,
  res: Response,
  renderTemplate: (
    res: Response,
    req: Request,
    template: string,
    data?: object
  ) => Promise<void>
) => {
  renderTemplate(res, req, "index");
};
