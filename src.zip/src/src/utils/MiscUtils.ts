import moment from "moment";
import "moment-duration-format";
import * as Intl from 'intl';
Intl.__disableRegExpRestore();

export class MiscUtils {
  /**
   * Method to find duplicates in an array
   * @param arr - The array to check for duplicates.
   * @returns An array of duplicate values.
   */
  public static findArrayDuplicates(arr: any[]): any[] {
    return arr.filter((value, index) => arr.indexOf(value) !== index);
  }

  /**
   * Method to format a number based on the provided language
   * @param value - The number to format.
   * @param language - The language code to use for formatting.
   * @returns The formatted number as a string.
   */
  public static formatNumber(value: number, language: string): string {
    const formatter = new Intl.NumberFormat(language);
    return formatter.format(value);
  }

  /**
   * Method to format a duration into "hh:mm:ss"
   * @param duration - The duration to format (in milliseconds).
   * @returns The formatted duration as a string.
   */
  public static formatDuration(duration: any): string {
    return moment.duration(duration).format("hh:mm:ss", { stopTrim: "m" });
  }

  /**
   * Method to capitalize the first letter of a string (or every word in it)
   * @param string - The string to capitalize.
   * @param everyWord - Whether to capitalize every word in the string (default is false).
   * @returns The capitalized string.
   */
  public static capitalizeFirstLetter(string: string, everyWord: boolean = false): string {
    const capitalizeWord = (w: string): string => w.charAt(0).toUpperCase() + w.slice(1);
    if (everyWord) return string.split(" ").map(capitalizeWord).join(" ");
    return capitalizeWord(string);
  }
};
