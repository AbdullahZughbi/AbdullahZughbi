import {
  Client,
  Guild,
  Message,
  TextChannel,
} from 'discord.js';

/**
 * Capitalizes a string.
 */
function capitalize(string: string): string {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

/**
 * Removes a specified value from an array.
 */
function removeElement<T>(arr: T[], value: T): T[] {
  const index = arr.indexOf(value);
  if (index > -1) arr.splice(index, 1);
  return arr;
}

/**
 * Trims an array down to a max length.
 */
function trimArray(arr: any[], maxLen = 10): any[] {
  if (arr.length > maxLen) {
    const len = arr.length - maxLen;
    arr = arr.slice(0, maxLen);
    arr.push(`and **${len}** more...`);
  }
  return arr;
}

/**
 * Joins an array to a string and trims it to a character limit.
 */
function trimStringFromArray(arr: string[], maxLen = 2048, joinChar = "\n"): string {
  let str = arr.join(joinChar);
  const cutoff = maxLen - 15;
  if (str.length > maxLen) {
    str = str.slice(0, cutoff);
    str = str.slice(0, str.lastIndexOf(joinChar));
    const remaining = arr.length - str.split(joinChar).length;
    str += `\nAnd **${remaining}** more...`;
  }
  return str;
}

/**
 * Gets the current window range in a paginated array.
 */
function getRange(arr: any[], current: number, interval: number): string {
  const max = Math.min(arr.length, current + interval);
  current += 1;
  return arr.length === 1 || arr.length === current || interval === 1
    ? `[${current}]`
    : `[${current} - ${max}]`;
}

/**
 * Returns the ordinal numeral form of a number.
 */
function getOrdinalNumeral(number: number): string {
  const nStr = number.toString();
  if (["11", "12", "13"].includes(nStr.slice(-2))) return `${nStr}th`;

  switch (nStr.slice(-1)) {
    case "1": return `${nStr}st`;
    case "2": return `${nStr}nd`;
    case "3": return `${nStr}rd`;
    default:  return `${nStr}th`;
  }
}

/**
 * Gets the next case number based on mod log messages.
 */
async function getCaseNumber(client: Client, guild: Guild, modLog: TextChannel): Promise<number> {
  const messages = await modLog.messages.fetch({ limit: 100 });
  const message = messages.find(m =>
    m.member?.id === guild.members.me?.id &&
    m.embeds.length > 0 &&
    m.embeds[0].footer?.text?.startsWith("Case")
  );

  if (message) {
    const footer = message.embeds[0].footer!.text;
    const num = parseInt(footer.split("#").pop() || "");
    if (!isNaN(num)) return num + 1;
  }

  return 1;
}

/**
 * Gets the status based on truthy values.
 */
function getStatus(...args: any[]): string {
  return args.every(Boolean) ? "enabled" : "disabled";
}

export {
  capitalize,
  removeElement,
  trimArray,
  trimStringFromArray,
  getRange,
  getOrdinalNumeral,
  getCaseNumber,
  getStatus,
};
