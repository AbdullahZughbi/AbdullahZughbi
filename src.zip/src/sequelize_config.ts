import fs from "fs";
import path from "path";
import util from "util";
import { Dialect } from "sequelize";

const logDirPath = path.join(__dirname, "src/assets/logs/query");
const logFilePath = path.join(logDirPath, "logs.json");

const ensureDirAndFile = (filePath: string) => {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, "[]", "utf8");
};

ensureDirAndFile(logFilePath);

interface LogEntry {
  sql: string;
  timing: number | null;
  timestamp: string;
}

const config = {
  HOST: "127.0.0.1",
  USER: "root",
  PASSWORD: "Abdullah12Star12A",
  DB: "godbot_ts",
  dialect: "mysql" as Dialect,
  dialectOptions: {
    connectTimeout: 60000,
  },
  pool: {
    max: 5,
    min: 0,
    acquire: 60000,
    idle: 10000,
  },

  // Sequelize-compatible logging function
  logging: true, /*(sql: string, timing?: number) => {
    try {
      const logEntry: LogEntry = {
        sql,
        timing: timing ?? null,
        timestamp: new Date().toISOString(),
      };

      const logs: LogEntry[] = JSON.parse(fs.readFileSync(logFilePath, "utf8"));
      logs.push(logEntry);
      fs.writeFileSync(logFilePath, JSON.stringify(logs, null, 2), "utf8");
    } catch (error) {
      console.error("[ERROR] Logging failed:", error);
    }
  },*/
};

export default config;
